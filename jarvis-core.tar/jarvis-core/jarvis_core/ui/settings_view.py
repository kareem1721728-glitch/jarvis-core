"""Settings view: API key, model, theme, font, autosave, memory controls."""
from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from ..config import Config
from ..theme import Palette
from .widgets import Card, SectionHeader, SettingRow, show_toast


class SettingsView(ctk.CTkFrame):
    def __init__(
        self,
        master,
        palette: Palette,
        config: Config,
        on_theme_change: Callable[[str], None],
        on_font_change: Callable[[str], None],
        on_clear_history: Callable[[], None],
        on_clear_memory_only: Callable[[], None],
    ):
        super().__init__(master, fg_color=palette.bg)
        self.palette = palette
        self.config = config
        self.on_theme_change = on_theme_change
        self.on_font_change = on_font_change
        self.on_clear_history = on_clear_history
        self.on_clear_memory_only = on_clear_memory_only

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        # Header
        header = ctk.CTkFrame(self, fg_color=palette.bg)
        header.grid(row=0, column=0, sticky="ew", padx=24, pady=(18, 6))
        ctk.CTkLabel(
            header,
            text="Settings",
            text_color=palette.text,
            font=ctk.CTkFont(size=22, weight="bold"),
            anchor="w",
        ).pack(anchor="w")
        ctk.CTkLabel(
            header,
            text="Application parameters",
            text_color=palette.text_muted,
            font=ctk.CTkFont(size=12),
            anchor="w",
        ).pack(anchor="w")

        # Scroll container
        scroll = ctk.CTkScrollableFrame(self, fg_color=palette.bg)
        scroll.grid(row=1, column=0, sticky="nsew", padx=24, pady=8)
        scroll.columnconfigure(0, weight=1)

        self._build_model_card(scroll)
        self._build_interface_card(scroll)
        self._build_memory_card(scroll)

    # ---------- model ----------
    def _build_model_card(self, parent) -> None:
        card = Card(parent, self.palette)
        card.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        card.columnconfigure(0, weight=1)

        SectionHeader(card, self.palette, "AI", "Model & API").grid(
            row=0, column=0, sticky="ew", padx=18, pady=(16, 6)
        )

        # API key
        api_entry = ctk.CTkEntry(
            card,
            width=320,
            height=34,
            corner_radius=10,
            fg_color=self.palette.surface_alt,
            border_color=self.palette.border,
            text_color=self.palette.text,
            show="•",
        )
        api_entry.insert(0, self.config.get("api_key", ""))

        def save_api(_event=None):
            self.config.set("api_key", api_entry.get().strip())
            show_toast(self.winfo_toplevel(), self.palette, "API key saved")

        api_entry.bind("<FocusOut>", save_api)
        api_entry.bind("<Return>", save_api)

        SettingRow(
            card,
            self.palette,
            "Gemini API key",
            "Your key is stored locally in config.json. Get one at aistudio.google.com.",
            api_entry,
        ).grid(row=1, column=0, sticky="ew", padx=18)

        # Model
        model_dd = ctk.CTkOptionMenu(
            card,
            width=220,
            height=34,
            corner_radius=10,
            fg_color=self.palette.surface_alt,
            button_color=self.palette.surface_alt,
            button_hover_color=self.palette.border,
            text_color=self.palette.text,
            values=["gemini-2.5-flash", "gemini-2.5-pro", "gemini-1.5-flash", "gemini-1.5-pro"],
            command=lambda v: (self.config.set("model", v), show_toast(self.winfo_toplevel(), self.palette, "Model updated", v)),
        )
        model_dd.set(self.config.get("model", "gemini-2.5-flash"))
        SettingRow(
            card,
            self.palette,
            "Model",
            "Switch between Gemini Flash (fast) and Pro (deeper reasoning).",
            model_dd,
        ).grid(row=2, column=0, sticky="ew", padx=18)

        # System prompt
        sys_entry = ctk.CTkTextbox(
            card,
            height=84,
            fg_color=self.palette.surface_alt,
            text_color=self.palette.text,
            border_width=0,
        )
        sys_entry.insert("1.0", self.config.get("system_prompt", ""))

        def save_sys(_e=None):
            self.config.set("system_prompt", sys_entry.get("1.0", "end").strip())

        sys_entry.bind("<FocusOut>", save_sys)
        sys_entry.grid(row=3, column=0, sticky="ew", padx=18, pady=(4, 16))
        ctk.CTkLabel(
            card,
            text="System prompt — sets the assistant's persona and rules.",
            text_color=self.palette.text_muted,
            font=ctk.CTkFont(size=11),
            anchor="w",
        ).grid(row=4, column=0, sticky="w", padx=18, pady=(0, 16))

    # ---------- interface ----------
    def _build_interface_card(self, parent) -> None:
        card = Card(parent, self.palette)
        card.grid(row=1, column=0, sticky="ew", pady=14)
        card.columnconfigure(0, weight=1)

        SectionHeader(card, self.palette, "UI", "Interface").grid(
            row=0, column=0, sticky="ew", padx=18, pady=(16, 6)
        )

        autosave_var = ctk.BooleanVar(value=bool(self.config.get("autosave", True)))
        autosave = ctk.CTkSwitch(
            card,
            text="",
            variable=autosave_var,
            command=lambda: self.config.set("autosave", autosave_var.get()),
            progress_color=self.palette.accent,
            button_color=self.palette.text,
        )
        SettingRow(
            card,
            self.palette,
            "Autosave",
            "Automatically save chat history between sessions.",
            autosave,
        ).grid(row=1, column=0, sticky="ew", padx=18)

        theme_dd = ctk.CTkOptionMenu(
            card,
            width=220,
            height=34,
            corner_radius=10,
            fg_color=self.palette.surface_alt,
            button_color=self.palette.surface_alt,
            button_hover_color=self.palette.border,
            text_color=self.palette.text,
            values=["Midnight", "Light"],
            command=self._on_theme_change,
        )
        theme_dd.set(self.config.get("theme", "Midnight"))
        SettingRow(
            card,
            self.palette,
            "Theme",
            "Base color theme for the application.",
            theme_dd,
        ).grid(row=2, column=0, sticky="ew", padx=18)

        font_dd = ctk.CTkOptionMenu(
            card,
            width=220,
            height=34,
            corner_radius=10,
            fg_color=self.palette.surface_alt,
            button_color=self.palette.surface_alt,
            button_hover_color=self.palette.border,
            text_color=self.palette.text,
            values=["Small", "Normal", "Large"],
            command=self._on_font_change,
        )
        font_dd.set(self.config.get("font_size", "Normal"))
        SettingRow(
            card,
            self.palette,
            "Font size",
            "Text scale across the entire interface.",
            font_dd,
        ).grid(row=3, column=0, sticky="ew", padx=18)

        gfont_entry = ctk.CTkEntry(
            card,
            width=220,
            height=34,
            corner_radius=10,
            fg_color=self.palette.surface_alt,
            border_color=self.palette.border,
            text_color=self.palette.text,
        )
        gfont_entry.insert(0, self.config.get("google_font", "Open Sans"))

        def save_font(_e=None):
            self.config.set("google_font", gfont_entry.get().strip() or "Open Sans")

        gfont_entry.bind("<FocusOut>", save_font)
        SettingRow(
            card,
            self.palette,
            "Google Font",
            "Font family from Google Fonts. Default: Open Sans.",
            gfont_entry,
        ).grid(row=4, column=0, sticky="ew", padx=18, pady=(0, 16))

    # ---------- memory ----------
    def _build_memory_card(self, parent) -> None:
        card = Card(parent, self.palette)
        card.grid(row=2, column=0, sticky="ew", pady=(14, 18))
        card.columnconfigure(0, weight=1)

        SectionHeader(card, self.palette, "DB", "Memory & data").grid(
            row=0, column=0, sticky="ew", padx=18, pady=(16, 6)
        )

        clear_btn = ctk.CTkButton(
            card,
            text="Clear",
            width=120,
            height=34,
            corner_radius=10,
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.danger,
            text_color=self.palette.text,
            command=self._handle_clear_history,
        )
        SettingRow(
            card,
            self.palette,
            "Clear chat memory",
            "Delete all messages and their full history.",
            clear_btn,
        ).grid(row=1, column=0, sticky="ew", padx=18)

        clear_mem_btn = ctk.CTkButton(
            card,
            text="Clear memory",
            width=120,
            height=34,
            corner_radius=10,
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.border,
            text_color=self.palette.text,
            command=self._handle_clear_memory_only,
        )
        SettingRow(
            card,
            self.palette,
            "Clear context only",
            "Reset the model context but keep the chat visible.",
            clear_mem_btn,
        ).grid(row=2, column=0, sticky="ew", padx=18, pady=(0, 16))

    def _on_theme_change(self, value: str) -> None:
        self.config.set("theme", value)
        self.on_theme_change(value)
        show_toast(self.winfo_toplevel(), self.palette, "Theme applied", value)

    def _on_font_change(self, value: str) -> None:
        self.config.set("font_size", value)
        self.on_font_change(value)
        show_toast(self.winfo_toplevel(), self.palette, "Font size", value)

    def _handle_clear_history(self) -> None:
        self.on_clear_history()
        show_toast(self.winfo_toplevel(), self.palette, "Chat memory cleared")

    def _handle_clear_memory_only(self) -> None:
        self.on_clear_memory_only()
        show_toast(self.winfo_toplevel(), self.palette, "Context cleared")
