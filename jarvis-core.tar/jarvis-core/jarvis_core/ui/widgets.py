"""Reusable UI primitives styled to match the Nexa aesthetic."""
from __future__ import annotations

from typing import Callable, Optional

import customtkinter as ctk

from ..theme import Palette


class Card(ctk.CTkFrame):
    """A rounded surface card with consistent padding and a 1px border."""

    def __init__(self, master, palette: Palette, **kwargs):
        super().__init__(
            master,
            corner_radius=14,
            fg_color=palette.surface,
            border_color=palette.border,
            border_width=1,
            **kwargs,
        )
        self.palette = palette


class SectionHeader(ctk.CTkFrame):
    """Icon + title row used inside settings cards."""

    def __init__(self, master, palette: Palette, icon: str, title: str):
        super().__init__(master, fg_color="transparent")
        self.columnconfigure(1, weight=1)
        ctk.CTkLabel(
            self,
            text=icon,
            text_color=palette.text,
            font=ctk.CTkFont(size=16),
            width=22,
        ).grid(row=0, column=0, sticky="w", padx=(2, 8))
        ctk.CTkLabel(
            self,
            text=title,
            text_color=palette.text,
            font=ctk.CTkFont(size=15, weight="bold"),
            anchor="w",
        ).grid(row=0, column=1, sticky="w")


class SettingRow(ctk.CTkFrame):
    """Title + description on the left, control widget on the right."""

    def __init__(
        self,
        master,
        palette: Palette,
        title: str,
        description: str,
        control: ctk.CTkBaseClass,
    ):
        super().__init__(master, fg_color="transparent")
        self.columnconfigure(0, weight=1)

        text_box = ctk.CTkFrame(self, fg_color="transparent")
        text_box.grid(row=0, column=0, sticky="ew", padx=(2, 12), pady=8)
        ctk.CTkLabel(
            text_box,
            text=title,
            text_color=palette.text,
            font=ctk.CTkFont(size=13, weight="bold"),
            anchor="w",
            justify="left",
        ).pack(fill="x", anchor="w")
        ctk.CTkLabel(
            text_box,
            text=description,
            text_color=palette.text_muted,
            font=ctk.CTkFont(size=12),
            anchor="w",
            justify="left",
            wraplength=420,
        ).pack(fill="x", anchor="w")

        control.grid(row=0, column=1, sticky="e", padx=(0, 4), pady=8)


class Toast(ctk.CTkFrame):
    """Bottom-right transient notification (matches the green-bar Nexa toast)."""

    def __init__(self, master, palette: Palette, title: str, subtitle: str = ""):
        super().__init__(
            master,
            corner_radius=10,
            fg_color=palette.surface_alt,
            border_color=palette.border,
            border_width=1,
        )
        accent_bar = ctk.CTkFrame(self, fg_color="#3DDC97", width=4, corner_radius=2)
        accent_bar.grid(row=0, column=0, rowspan=2, sticky="ns", padx=(8, 8), pady=8)
        ctk.CTkLabel(
            self,
            text=title,
            text_color=palette.text,
            font=ctk.CTkFont(size=13, weight="bold"),
            anchor="w",
        ).grid(row=0, column=1, sticky="w", padx=(0, 14), pady=(8, 0))
        if subtitle:
            ctk.CTkLabel(
                self,
                text=subtitle,
                text_color=palette.text_muted,
                font=ctk.CTkFont(size=12),
                anchor="w",
            ).grid(row=1, column=1, sticky="w", padx=(0, 14), pady=(0, 8))


def show_toast(root, palette: Palette, title: str, subtitle: str = "", ms: int = 2200) -> None:
    """Pop a toast in the bottom-right and auto-dismiss."""
    toast = Toast(root, palette, title, subtitle)
    toast.place(relx=1.0, rely=1.0, x=-20, y=-20, anchor="se")
    root.after(ms, toast.destroy)


class IconButton(ctk.CTkButton):
    """Square icon-only button used in the sidebar."""

    def __init__(
        self,
        master,
        palette: Palette,
        icon: str,
        command: Callable,
        active: bool = False,
        tooltip: Optional[str] = None,
    ):
        self.palette = palette
        self._active = active
        super().__init__(
            master,
            text=icon,
            command=command,
            width=40,
            height=40,
            corner_radius=10,
            font=ctk.CTkFont(size=18),
            fg_color=palette.surface_alt if active else "transparent",
            hover_color=palette.surface_alt,
            text_color=palette.accent if active else palette.text_muted,
            border_width=0,
        )
        self._tooltip = tooltip

    def set_active(self, active: bool) -> None:
        self._active = active
        self.configure(
            fg_color=self.palette.surface_alt if active else "transparent",
            text_color=self.palette.accent if active else self.palette.text_muted,
        )
