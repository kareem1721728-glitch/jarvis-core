"""Profile view: shows the user a summary of usage and config location."""
from __future__ import annotations

import customtkinter as ctk

from ..config import Config
from ..theme import Palette
from .widgets import Card, SectionHeader


class ProfileView(ctk.CTkFrame):
    def __init__(self, master, palette: Palette, config: Config, token_getter):
        super().__init__(master, fg_color=palette.bg)
        self.palette = palette
        self.config = config
        self.token_getter = token_getter

        self.columnconfigure(0, weight=1)

        ctk.CTkLabel(
            self,
            text="Profile",
            text_color=palette.text,
            font=ctk.CTkFont(size=22, weight="bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="w", padx=24, pady=(18, 6))

        card = Card(self, palette)
        card.grid(row=1, column=0, sticky="ew", padx=24, pady=8)
        card.columnconfigure(0, weight=1)

        SectionHeader(card, palette, "U", "Local profile").grid(
            row=0, column=0, sticky="ew", padx=18, pady=(16, 6)
        )

        info = [
            ("Active model", self.config.get("model", "—")),
            ("Theme", self.config.get("theme", "—")),
            ("Font size", self.config.get("font_size", "—")),
            ("Autosave", "On" if self.config.get("autosave") else "Off"),
            ("Config file", str(self.config.path)),
            ("Last response tokens", str(self.token_getter())),
            ("History messages", str(len(self.config.get("history", []) or []))),
            ("Saved commands", str(len(self.config.get("commands", []) or []))),
        ]
        for i, (k, v) in enumerate(info):
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.grid(row=i + 1, column=0, sticky="ew", padx=18, pady=6)
            row.columnconfigure(1, weight=1)
            ctk.CTkLabel(
                row,
                text=k,
                text_color=palette.text_muted,
                font=ctk.CTkFont(size=12),
                anchor="w",
            ).grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(
                row,
                text=v,
                text_color=palette.text,
                font=ctk.CTkFont(size=13),
                anchor="e",
                justify="right",
                wraplength=520,
            ).grid(row=0, column=1, sticky="e")

        ctk.CTkLabel(card, text=" ", fg_color="transparent").grid(row=99, column=0, pady=8)
