"""Chat view: scrollable transcript + input row + drag-and-drop hints."""
from __future__ import annotations

import os
from typing import Callable, Optional

import customtkinter as ctk
from tkinter import filedialog

from ..gemini_client import ChatMessage, GeminiClient, GeminiResult
from ..theme import Palette
from .widgets import show_toast


class _Bubble(ctk.CTkFrame):
    def __init__(self, master, palette: Palette, role: str, text: str, font_scale: str):
        is_user = role == "user"
        bg = palette.user_bubble if is_user else palette.assistant_bubble
        super().__init__(
            master,
            corner_radius=14,
            fg_color=bg,
            border_color=palette.border,
            border_width=1,
        )
        label_role = ctk.CTkLabel(
            self,
            text="You" if is_user else "JARVIS",
            text_color=palette.accent if not is_user else palette.text_muted,
            font=ctk.CTkFont(size=11, weight="bold"),
            anchor="w",
        )
        label_role.grid(row=0, column=0, sticky="w", padx=14, pady=(10, 0))
        body = ctk.CTkLabel(
            self,
            text=text,
            text_color=palette.text,
            font=ctk.CTkFont(size=13),
            anchor="w",
            justify="left",
            wraplength=620,
        )
        body.grid(row=1, column=0, sticky="ew", padx=14, pady=(2, 12))


class ChatView(ctk.CTkFrame):
    def __init__(
        self,
        master,
        palette: Palette,
        client: GeminiClient,
        history: list[ChatMessage],
        on_history_change: Callable[[], None],
        on_token_update: Callable[[int], None],
        terminal_mode_getter: Callable[[], bool],
        on_run_command: Callable[[str], None],
        font_scale: str = "Normal",
    ):
        super().__init__(master, fg_color=palette.bg)
        self.palette = palette
        self.client = client
        self.history = history
        self.on_history_change = on_history_change
        self.on_token_update = on_token_update
        self.terminal_mode_getter = terminal_mode_getter
        self.on_run_command = on_run_command
        self.font_scale = font_scale
        self.attached_image: Optional[str] = None

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        # Header
        header = ctk.CTkFrame(self, fg_color=palette.bg, height=48)
        header.grid(row=0, column=0, sticky="ew", padx=24, pady=(18, 6))
        header.columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header,
            text="Chat",
            text_color=palette.text,
            font=ctk.CTkFont(size=22, weight="bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="w")
        self.status_label = ctk.CTkLabel(
            header,
            text="Ready",
            text_color=palette.text_muted,
            font=ctk.CTkFont(size=12),
        )
        self.status_label.grid(row=0, column=1, sticky="e")

        # Transcript
        self.transcript = ctk.CTkScrollableFrame(
            self,
            fg_color=palette.surface,
            corner_radius=14,
            border_color=palette.border,
            border_width=1,
        )
        self.transcript.grid(row=1, column=0, sticky="nsew", padx=24, pady=8)
        self.transcript.columnconfigure(0, weight=1)

        # Input row
        input_box = ctk.CTkFrame(
            self,
            fg_color=palette.surface,
            corner_radius=14,
            border_color=palette.border,
            border_width=1,
        )
        input_box.grid(row=2, column=0, sticky="ew", padx=24, pady=(8, 18))
        input_box.columnconfigure(0, weight=1)

        self.attach_label = ctk.CTkLabel(
            input_box,
            text="",
            text_color=palette.text_muted,
            font=ctk.CTkFont(size=11),
            anchor="w",
        )
        self.attach_label.grid(row=0, column=0, columnspan=3, sticky="ew", padx=14, pady=(8, 0))

        self.entry = ctk.CTkTextbox(
            input_box,
            height=70,
            fg_color=palette.surface,
            text_color=palette.text,
            border_width=0,
            font=ctk.CTkFont(size=13),
            wrap="word",
        )
        self.entry.grid(row=1, column=0, sticky="ew", padx=(14, 8), pady=(4, 10))
        self.entry.bind("<Control-Return>", self._on_send_event)

        ctk.CTkButton(
            input_box,
            text="Attach",
            width=84,
            height=34,
            corner_radius=10,
            fg_color=palette.surface_alt,
            hover_color=palette.border,
            text_color=palette.text,
            command=self._attach_file,
        ).grid(row=1, column=1, sticky="e", padx=(0, 6), pady=(4, 10))

        self.send_btn = ctk.CTkButton(
            input_box,
            text="Send",
            width=96,
            height=34,
            corner_radius=10,
            fg_color=palette.accent,
            hover_color=palette.accent_hover,
            text_color=palette.accent_text,
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self._on_send,
        )
        self.send_btn.grid(row=1, column=2, sticky="e", padx=(0, 14), pady=(4, 10))

        self._render_history()

    # ---------- public API ----------
    def update_token_count(self, n: int) -> None:
        self.status_label.configure(text=f"{n} tokens" if n else "Ready")

    def clear_history(self) -> None:
        self.history.clear()
        for w in self.transcript.winfo_children():
            w.destroy()
        self.update_token_count(0)
        self.on_token_update(0)
        self.on_history_change()

    # ---------- helpers ----------
    def _render_history(self) -> None:
        for w in self.transcript.winfo_children():
            w.destroy()
        if not self.history:
            empty = ctk.CTkLabel(
                self.transcript,
                text="Start a conversation. Tip: drag-and-drop is replaced by the Attach button — supports images and text files.",
                text_color=self.palette.text_muted,
                font=ctk.CTkFont(size=12),
                wraplength=520,
                justify="center",
            )
            empty.grid(row=0, column=0, pady=40)
            return
        for i, msg in enumerate(self.history):
            bubble = _Bubble(self.transcript, self.palette, msg.role, msg.text, self.font_scale)
            bubble.grid(
                row=i,
                column=0,
                sticky="ew" if msg.role == "model" else "e",
                padx=(8, 80) if msg.role == "model" else (80, 8),
                pady=6,
            )

    def _attach_file(self) -> None:
        path = filedialog.askopenfilename(
            filetypes=[
                ("Images", "*.png *.jpg *.jpeg *.webp *.gif"),
                ("Text", "*.txt *.md *.py *.json *.log"),
                ("All files", "*.*"),
            ]
        )
        if not path:
            return
        ext = os.path.splitext(path)[1].lower()
        if ext in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
            self.attached_image = path
            self.attach_label.configure(text=f"Image attached: {os.path.basename(path)}")
        else:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    text = f.read()
                current = self.entry.get("1.0", "end").strip()
                snippet = f"\n\n--- {os.path.basename(path)} ---\n{text}"
                self.entry.insert("end", snippet if current else snippet.lstrip())
                self.attach_label.configure(text=f"Loaded text: {os.path.basename(path)}")
            except OSError as exc:
                self.attach_label.configure(text=f"Could not read file: {exc}")

    def _on_send_event(self, _event) -> str:
        self._on_send()
        return "break"

    def _on_send(self) -> None:
        text = self.entry.get("1.0", "end").strip()
        if not text and not self.attached_image:
            return
        if not self.client.api_key:
            show_toast(
                self.winfo_toplevel(),
                self.palette,
                "API key missing",
                "Add your Gemini API key in Settings.",
            )
            return

        # Append user message
        user_msg = ChatMessage(role="user", text=text, image_path=self.attached_image)
        self.history.append(user_msg)
        self._render_history()
        self.entry.delete("1.0", "end")
        attached = self.attached_image
        self.attached_image = None
        self.attach_label.configure(text="")

        self.send_btn.configure(state="disabled", text="...")
        self.status_label.configure(text="Thinking...")

        # History sent to API excludes the just-added message; pass the prompt separately.
        history_for_api = self.history[:-1]

        def on_done(result: GeminiResult) -> None:
            self.after(0, lambda: self._handle_result(result))

        self.client.send_async(
            prompt=text,
            history=history_for_api,
            on_done=on_done,
            image_path=attached,
        )

    def _handle_result(self, result: GeminiResult) -> None:
        self.send_btn.configure(state="normal", text="Send")
        if not result.ok:
            self.status_label.configure(text="Error")
            show_toast(self.winfo_toplevel(), self.palette, "Request failed", result.error[:120])
            return
        msg = ChatMessage(role="model", text=result.text)
        self.history.append(msg)
        self._render_history()
        self.update_token_count(result.token_count)
        self.on_token_update(result.token_count)
        self.on_history_change()

        if self.terminal_mode_getter():
            command = self._extract_command(result.text)
            if command:
                self._confirm_and_run(command)

    def _extract_command(self, text: str) -> Optional[str]:
        # Pull the first fenced code block as the candidate command.
        if "```" not in text:
            return None
        parts = text.split("```")
        if len(parts) < 2:
            return None
        block = parts[1]
        # Drop language tag like "powershell\n..."
        if "\n" in block:
            first, rest = block.split("\n", 1)
            if first.strip().lower() in {"powershell", "ps", "cmd", "bash", "sh", ""}:
                return rest.strip()
            return block.strip()
        return block.strip()

    def _confirm_and_run(self, command: str) -> None:
        dlg = ctk.CTkToplevel(self)
        dlg.title("Confirm command")
        dlg.geometry("520x260")
        dlg.configure(fg_color=self.palette.surface)
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        ctk.CTkLabel(
            dlg,
            text="Run this system command?",
            text_color=self.palette.text,
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(anchor="w", padx=18, pady=(16, 6))
        box = ctk.CTkTextbox(dlg, fg_color=self.palette.surface_alt, text_color=self.palette.text)
        box.pack(fill="both", expand=True, padx=18, pady=8)
        box.insert("1.0", command)
        box.configure(state="disabled")

        row = ctk.CTkFrame(dlg, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=(4, 16))
        ctk.CTkButton(
            row,
            text="Cancel",
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.border,
            text_color=self.palette.text,
            command=dlg.destroy,
        ).pack(side="right", padx=(8, 0))
        ctk.CTkButton(
            row,
            text="Confirm & Run",
            fg_color=self.palette.accent,
            hover_color=self.palette.accent_hover,
            text_color=self.palette.accent_text,
            command=lambda: (self.on_run_command(command), dlg.destroy()),
        ).pack(side="right")
