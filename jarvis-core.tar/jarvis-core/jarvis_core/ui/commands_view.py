"""Commands view: define & manage custom commands (mirrors the Nexa "Команды" screen)."""
from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from ..config import Config
from ..theme import Palette
from .widgets import Card, show_toast


COMMAND_TYPES = [
    ("System", "Apps & system"),
    ("Chain", "Multiple steps"),
    ("Keys", "Key combos"),
    ("AI", "Model query"),
    ("Custom", "Free-form text"),
]


class CommandsView(ctk.CTkFrame):
    def __init__(self, master, palette: Palette, config: Config, on_run: Callable[[str], None]):
        super().__init__(master, fg_color=palette.bg)
        self.palette = palette
        self.config = config
        self.on_run = on_run

        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        # Header
        header = ctk.CTkFrame(self, fg_color=palette.bg)
        header.grid(row=0, column=0, sticky="ew", padx=24, pady=(18, 6))
        header.columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header,
            text="Commands",
            text_color=palette.text,
            font=ctk.CTkFont(size=22, weight="bold"),
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkButton(
            header,
            text="+ New command",
            width=140,
            height=34,
            corner_radius=10,
            fg_color=palette.accent,
            hover_color=palette.accent_hover,
            text_color=palette.accent_text,
            command=self._open_new_command,
        ).grid(row=0, column=1, sticky="e")

        ctk.CTkLabel(
            self,
            text="Save shell or AI commands and run them in one click.",
            text_color=palette.text_muted,
            font=ctk.CTkFont(size=12),
            anchor="w",
        ).grid(row=1, column=0, sticky="w", padx=24)

        # List
        self.list_frame = ctk.CTkScrollableFrame(self, fg_color=palette.bg)
        self.list_frame.grid(row=2, column=0, sticky="nsew", padx=24, pady=(8, 18))
        self.list_frame.columnconfigure(0, weight=1)

        self._render_list()

    def _render_list(self) -> None:
        for w in self.list_frame.winfo_children():
            w.destroy()
        commands = self.config.get("commands", []) or []
        if not commands:
            ctk.CTkLabel(
                self.list_frame,
                text="No commands yet. Click '+ New command' to create one.",
                text_color=self.palette.text_muted,
                font=ctk.CTkFont(size=12),
            ).grid(row=0, column=0, pady=40)
            return
        for i, cmd in enumerate(commands):
            self._render_command_row(i, cmd)

    def _render_command_row(self, idx: int, cmd: dict) -> None:
        card = Card(self.list_frame, self.palette)
        card.grid(row=idx, column=0, sticky="ew", pady=6)
        card.columnconfigure(1, weight=1)

        ctk.CTkLabel(
            card,
            text=cmd.get("type", "Custom")[:1] or "C",
            text_color=self.palette.accent_text,
            fg_color=self.palette.accent,
            corner_radius=8,
            width=36,
            height=36,
            font=ctk.CTkFont(size=14, weight="bold"),
        ).grid(row=0, column=0, rowspan=2, padx=14, pady=12)

        ctk.CTkLabel(
            card,
            text=cmd.get("name", "Untitled"),
            text_color=self.palette.text,
            font=ctk.CTkFont(size=13, weight="bold"),
            anchor="w",
        ).grid(row=0, column=1, sticky="ew", pady=(12, 0))
        ctk.CTkLabel(
            card,
            text=cmd.get("action", ""),
            text_color=self.palette.text_muted,
            font=ctk.CTkFont(size=12),
            anchor="w",
            wraplength=440,
            justify="left",
        ).grid(row=1, column=1, sticky="ew", pady=(0, 12))

        btns = ctk.CTkFrame(card, fg_color="transparent")
        btns.grid(row=0, column=2, rowspan=2, padx=12)
        ctk.CTkButton(
            btns,
            text="Run",
            width=70,
            height=30,
            corner_radius=8,
            fg_color=self.palette.accent,
            hover_color=self.palette.accent_hover,
            text_color=self.palette.accent_text,
            command=lambda c=cmd: self.on_run(c.get("action", "")),
        ).pack(side="left", padx=4)
        ctk.CTkButton(
            btns,
            text="Delete",
            width=70,
            height=30,
            corner_radius=8,
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.danger,
            text_color=self.palette.text,
            command=lambda i=idx: self._delete(i),
        ).pack(side="left", padx=4)

    def _delete(self, idx: int) -> None:
        commands = list(self.config.get("commands", []) or [])
        if 0 <= idx < len(commands):
            commands.pop(idx)
            self.config.set("commands", commands)
            self._render_list()

    def _open_new_command(self) -> None:
        dlg = ctk.CTkToplevel(self)
        dlg.title("New command")
        dlg.geometry("560x560")
        dlg.configure(fg_color=self.palette.surface)
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()

        ctk.CTkLabel(
            dlg,
            text="New command",
            text_color=self.palette.text,
            font=ctk.CTkFont(size=18, weight="bold"),
        ).pack(anchor="w", padx=20, pady=(18, 0))
        ctk.CTkLabel(
            dlg,
            text="Fill in the fields below — the command appears in the list and is callable from chat.",
            text_color=self.palette.text_muted,
            font=ctk.CTkFont(size=12),
            wraplength=520,
            justify="left",
        ).pack(anchor="w", padx=20, pady=(2, 12))

        name_entry = ctk.CTkEntry(
            dlg,
            placeholder_text="Command name",
            height=36,
            fg_color=self.palette.surface_alt,
            border_color=self.palette.border,
            text_color=self.palette.text,
        )
        name_entry.pack(fill="x", padx=20, pady=4)

        desc_entry = ctk.CTkTextbox(
            dlg,
            height=70,
            fg_color=self.palette.surface_alt,
            text_color=self.palette.text,
            border_width=0,
        )
        desc_entry.pack(fill="x", padx=20, pady=4)
        desc_entry.insert("1.0", "")

        ctk.CTkLabel(
            dlg,
            text="Command type *",
            text_color=self.palette.text,
            font=ctk.CTkFont(size=13, weight="bold"),
        ).pack(anchor="w", padx=20, pady=(10, 4))

        type_holder = ctk.CTkFrame(dlg, fg_color="transparent")
        type_holder.pack(fill="x", padx=20)
        for c in range(3):
            type_holder.columnconfigure(c, weight=1)

        selected_type = {"v": "System"}
        type_buttons: list[ctk.CTkButton] = []

        def select(t: str) -> None:
            selected_type["v"] = t
            for btn, (label, _) in zip(type_buttons, COMMAND_TYPES):
                active = label == t
                btn.configure(
                    fg_color=self.palette.accent if active else self.palette.surface_alt,
                    text_color=self.palette.accent_text if active else self.palette.text,
                )

        for i, (label, sub) in enumerate(COMMAND_TYPES):
            btn = ctk.CTkButton(
                type_holder,
                text=f"{label}\n{sub}",
                height=58,
                corner_radius=10,
                fg_color=self.palette.surface_alt,
                hover_color=self.palette.border,
                text_color=self.palette.text,
                command=lambda l=label: select(l),
            )
            btn.grid(row=i // 3, column=i % 3, padx=4, pady=4, sticky="ew")
            type_buttons.append(btn)
        select("System")

        ctk.CTkLabel(
            dlg,
            text="Action *",
            text_color=self.palette.text,
            font=ctk.CTkFont(size=13, weight="bold"),
        ).pack(anchor="w", padx=20, pady=(12, 4))
        action_entry = ctk.CTkEntry(
            dlg,
            placeholder_text="What to run: app name, keys:^c, text for AI...",
            height=36,
            fg_color=self.palette.surface_alt,
            border_color=self.palette.border,
            text_color=self.palette.text,
        )
        action_entry.pack(fill="x", padx=20, pady=4)

        # Footer
        footer = ctk.CTkFrame(dlg, fg_color="transparent")
        footer.pack(side="bottom", fill="x", padx=20, pady=14)

        def save():
            name = name_entry.get().strip()
            action = action_entry.get().strip()
            if not name or not action:
                show_toast(dlg, self.palette, "Name and action are required")
                return
            commands = list(self.config.get("commands", []) or [])
            commands.append(
                {
                    "name": name,
                    "description": desc_entry.get("1.0", "end").strip(),
                    "type": selected_type["v"],
                    "action": action,
                }
            )
            self.config.set("commands", commands)
            self._render_list()
            dlg.destroy()
            show_toast(self.winfo_toplevel(), self.palette, "Command saved")

        ctk.CTkButton(
            footer,
            text="Cancel",
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.border,
            text_color=self.palette.text,
            width=100,
            command=dlg.destroy,
        ).pack(side="right", padx=(8, 0))
        ctk.CTkButton(
            footer,
            text="Save",
            fg_color=self.palette.accent,
            hover_color=self.palette.accent_hover,
            text_color=self.palette.accent_text,
            width=120,
            command=save,
        ).pack(side="right")
