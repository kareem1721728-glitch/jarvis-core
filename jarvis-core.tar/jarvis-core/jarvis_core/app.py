"""Main JARVIS-CORE application shell.

Owns the sidebar navigation, view switching, theme application, and lifecycle.
"""
from __future__ import annotations

import customtkinter as ctk

from .config import Config
from .gemini_client import ChatMessage, GeminiClient
from .system_runner import run_command
from .theme import Palette, get_palette, scaled
from .ui.chat_view import ChatView
from .ui.commands_view import CommandsView
from .ui.profile_view import ProfileView
from .ui.settings_view import SettingsView
from .ui.widgets import IconButton, show_toast


SIDEBAR_ITEMS = [
    ("home", "⌂", "Chat"),
    ("commands", "≡", "Commands"),
    ("settings", "⚙", "Settings"),
    ("profile", "◎", "Profile"),
]


class JarvisApp(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.config_obj = Config()
        self.palette: Palette = get_palette(self.config_obj.get("theme", "Midnight"))
        self.font_scale: str = self.config_obj.get("font_size", "Normal")

        self.title("Nexa  |  JARVIS-CORE")
        self.geometry("1200x760")
        self.minsize(960, 620)
        self.configure(fg_color=self.palette.bg)

        ctk.set_appearance_mode("dark" if self.palette.name == "Midnight" else "light")

        # Domain state
        self.history: list[ChatMessage] = self._load_history()
        self.last_token_count: int = 0
        self.terminal_mode: bool = False

        self.client = GeminiClient(
            api_key=self.config_obj.get("api_key", ""),
            model_name=self.config_obj.get("model", "gemini-2.5-flash"),
            system_prompt=self.config_obj.get("system_prompt", ""),
        )

        self._build_layout()
        self._show_view("home")

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------- layout ----------
    def _build_layout(self) -> None:
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

        # Title bar
        title_bar = ctk.CTkFrame(self, fg_color=self.palette.sidebar, height=44, corner_radius=0)
        title_bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        title_bar.columnconfigure(2, weight=1)

        ctk.CTkLabel(
            title_bar,
            text="Nexa",
            text_color=self.palette.text,
            font=ctk.CTkFont(size=14, weight="bold"),
        ).grid(row=0, column=0, padx=(20, 8), pady=10)

        self.section_label = ctk.CTkLabel(
            title_bar,
            text="Application parameters",
            text_color=self.palette.text_muted,
            font=ctk.CTkFont(size=12),
        )
        self.section_label.grid(row=0, column=1, padx=(0, 12), pady=10, sticky="w")

        # Terminal mode toggle on the right
        terminal_var = ctk.BooleanVar(value=False)

        def toggle_terminal():
            self.terminal_mode = terminal_var.get()
            show_toast(
                self,
                self.palette,
                f"Terminal mode {'on' if self.terminal_mode else 'off'}",
                "Code blocks become runnable commands." if self.terminal_mode else "",
            )

        ctk.CTkSwitch(
            title_bar,
            text="Terminal",
            variable=terminal_var,
            command=toggle_terminal,
            text_color=self.palette.text_muted,
            progress_color=self.palette.accent,
        ).grid(row=0, column=3, padx=(0, 16))

        self.token_label = ctk.CTkLabel(
            title_bar,
            text="0 tokens",
            text_color=self.palette.text_muted,
            font=ctk.CTkFont(size=12),
        )
        self.token_label.grid(row=0, column=4, padx=(0, 20))

        # Sidebar
        sidebar = ctk.CTkFrame(self, fg_color=self.palette.sidebar, width=68, corner_radius=0)
        sidebar.grid(row=1, column=0, sticky="ns")
        sidebar.grid_propagate(False)

        self.sidebar_buttons: dict[str, IconButton] = {}
        for i, (key, icon, _label) in enumerate(SIDEBAR_ITEMS):
            btn = IconButton(
                sidebar,
                self.palette,
                icon=icon,
                command=lambda k=key: self._show_view(k),
                active=False,
            )
            btn.grid(row=i, column=0, padx=14, pady=(18 if i == 0 else 8, 0))
            self.sidebar_buttons[key] = btn

        # Content host
        self.content = ctk.CTkFrame(self, fg_color=self.palette.bg, corner_radius=0)
        self.content.grid(row=1, column=1, sticky="nsew")
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=1)

        self._views: dict[str, ctk.CTkFrame] = {}

    # ---------- view lifecycle ----------
    def _build_view(self, key: str) -> ctk.CTkFrame:
        if key == "home":
            view = ChatView(
                self.content,
                self.palette,
                self.client,
                self.history,
                on_history_change=self._save_history,
                on_token_update=self._update_tokens,
                terminal_mode_getter=lambda: self.terminal_mode,
                on_run_command=self._run_command,
                font_scale=self.font_scale,
            )
        elif key == "commands":
            view = CommandsView(self.content, self.palette, self.config_obj, on_run=self._run_command)
        elif key == "settings":
            view = SettingsView(
                self.content,
                self.palette,
                self.config_obj,
                on_theme_change=self._apply_theme,
                on_font_change=self._apply_font,
                on_clear_history=self._clear_history,
                on_clear_memory_only=self._clear_memory_only,
            )
        elif key == "profile":
            view = ProfileView(self.content, self.palette, self.config_obj, lambda: self.last_token_count)
        else:
            view = ctk.CTkFrame(self.content, fg_color=self.palette.bg)
        return view

    def _show_view(self, key: str) -> None:
        # Lazily build to keep memory low
        for k, btn in self.sidebar_buttons.items():
            btn.set_active(k == key)
        for v in self._views.values():
            v.grid_forget()
        if key not in self._views:
            self._views[key] = self._build_view(key)
        self._views[key].grid(row=0, column=0, sticky="nsew")
        self.section_label.configure(text={
            "home": "Chat",
            "commands": "Commands",
            "settings": "Application parameters",
            "profile": "Profile",
        }.get(key, ""))

    # ---------- callbacks ----------
    def _save_history(self) -> None:
        if not self.config_obj.get("autosave", True):
            return
        serialized = [
            {"role": m.role, "text": m.text, "image_path": m.image_path}
            for m in self.history
        ]
        self.config_obj.set("history", serialized)

    def _load_history(self) -> list[ChatMessage]:
        raw = self.config_obj.get("history", []) or []
        out: list[ChatMessage] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            out.append(
                ChatMessage(
                    role=item.get("role", "user"),
                    text=item.get("text", ""),
                    image_path=item.get("image_path"),
                )
            )
        return out

    def _update_tokens(self, n: int) -> None:
        self.last_token_count = n
        self.token_label.configure(text=f"{n} tokens" if n else "0 tokens")

    def _clear_history(self) -> None:
        view = self._views.get("home")
        if isinstance(view, ChatView):
            view.clear_history()
        else:
            self.history.clear()
        self.config_obj.set("history", [])
        self._update_tokens(0)

    def _clear_memory_only(self) -> None:
        # Mark a context boundary by inserting a system marker that the API ignores.
        # In practice, rebuild a fresh chat next call by trimming server-visible history.
        self.history.clear()
        view = self._views.get("home")
        if isinstance(view, ChatView):
            view._render_history()  # noqa: SLF001
        self._save_history()

    def _run_command(self, command: str) -> None:
        if not command.strip():
            return
        result = run_command(command)
        title = "Command finished" if result.ok else "Command failed"
        body = (result.stdout or result.stderr or "").strip().splitlines()
        subtitle = body[0][:80] if body else f"exit {result.returncode}"
        show_toast(self, self.palette, title, subtitle)

    # ---------- theme/font ----------
    def _apply_theme(self, name: str) -> None:
        self.palette = get_palette(name)
        ctk.set_appearance_mode("dark" if self.palette.name == "Midnight" else "light")
        # Rebuild from scratch so all child widgets pick up the new palette.
        for child in list(self.children.values()):
            child.destroy()
        self._views.clear()
        self.configure(fg_color=self.palette.bg)
        self._build_layout()
        self._show_view("home")

    def _apply_font(self, scale_name: str) -> None:
        self.font_scale = scale_name
        # Apply at the next view rebuild
        self._apply_theme(self.palette.name)

    # ---------- lifecycle ----------
    def _on_close(self) -> None:
        try:
            self._save_history()
            self.config_obj.save()
        finally:
            self.destroy()


def run() -> None:
    ctk.set_default_color_theme("blue")
    app = JarvisApp()
    app.mainloop()
