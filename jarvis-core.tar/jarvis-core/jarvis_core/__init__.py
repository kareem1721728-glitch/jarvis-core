"""JARVIS-CORE - The Nexa Evolution. Personal AI Assistant for Windows."""
__version__ = "1.0.0"
