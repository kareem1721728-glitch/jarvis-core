"""Run shell commands (PowerShell on Windows, sh elsewhere) safely with timeout."""
from __future__ import annotations

import platform
import subprocess
from dataclasses import dataclass


@dataclass
class CommandResult:
    ok: bool
    stdout: str
    stderr: str
    returncode: int


def run_command(command: str, timeout: int = 30) -> CommandResult:
    """Execute a shell command. On Windows, uses PowerShell; otherwise /bin/sh.

    Always invoked manually after explicit user confirmation in the UI.
    """
    is_windows = platform.system().lower().startswith("win")
    try:
        if is_windows:
            args = [
                "powershell.exe",
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                command,
            ]
            proc = subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=timeout,
                shell=False,
            )
        else:
            proc = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout,
                shell=True,
                executable="/bin/sh",
            )
        return CommandResult(
            ok=(proc.returncode == 0),
            stdout=proc.stdout,
            stderr=proc.stderr,
            returncode=proc.returncode,
        )
    except subprocess.TimeoutExpired:
        return CommandResult(False, "", f"Timed out after {timeout}s", -1)
    except Exception as exc:  # noqa: BLE001
        return CommandResult(False, "", str(exc), -1)
