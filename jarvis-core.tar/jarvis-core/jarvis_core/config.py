"""Configuration manager. Persists settings/API keys to a local config.json file."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any


def _app_data_dir() -> Path:
    """Return a writable per-user app-data directory.

    On Windows: %APPDATA%/JARVIS-CORE
    On other OSes: ~/.jarvis-core
    Falls back to the executable directory for portable mode.
    """
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or str(Path.home())
        return Path(base) / "JARVIS-CORE"
    return Path.home() / ".jarvis-core"


DEFAULTS: dict[str, Any] = {
    "api_key": "",
    "model": "gemini-2.5-flash",
    "theme": "Midnight",
    "font_size": "Normal",
    "google_font": "Open Sans",
    "autosave": True,
    "system_prompt": "You are JARVIS, a concise and helpful personal assistant.",
    "history": [],
    "commands": [],
}


class Config:
    """Lightweight JSON config with autosave."""

    def __init__(self, path: Path | None = None) -> None:
        self.path: Path = path or (_app_data_dir() / "config.json")
        self._data: dict[str, Any] = dict(DEFAULTS)
        self.load()

    def load(self) -> None:
        try:
            if self.path.exists():
                with self.path.open("r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    merged = dict(DEFAULTS)
                    merged.update(loaded)
                    self._data = merged
        except (OSError, json.JSONDecodeError):
            self._data = dict(DEFAULTS)

    def save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)
        except OSError:
            pass

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any, *, autosave: bool = True) -> None:
        self._data[key] = value
        if autosave:
            self.save()

    def update(self, values: dict[str, Any], *, autosave: bool = True) -> None:
        self._data.update(values)
        if autosave:
            self.save()

    @property
    def all(self) -> dict[str, Any]:
        return dict(self._data)
