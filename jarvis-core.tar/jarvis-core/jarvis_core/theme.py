"""Theme palettes for JARVIS-CORE. Matches the Nexa Midnight/Light aesthetic."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    name: str
    bg: str
    surface: str
    surface_alt: str
    sidebar: str
    border: str
    text: str
    text_muted: str
    accent: str
    accent_hover: str
    accent_text: str
    user_bubble: str
    assistant_bubble: str
    danger: str


MIDNIGHT = Palette(
    name="Midnight",
    bg="#0B1220",
    surface="#111A2E",
    surface_alt="#172238",
    sidebar="#0A1020",
    border="#1F2C46",
    text="#E6ECF5",
    text_muted="#8C9AB5",
    accent="#5DA8FF",
    accent_hover="#7CBBFF",
    accent_text="#0B1220",
    user_bubble="#1B2A47",
    assistant_bubble="#142039",
    danger="#FF6B6B",
)

LIGHT = Palette(
    name="Light",
    bg="#F6F2EA",
    surface="#FFFFFF",
    surface_alt="#F1ECE2",
    sidebar="#EFE9DD",
    border="#E0D8C8",
    text="#1F2230",
    text_muted="#6B6B72",
    accent="#3D7DD0",
    accent_hover="#5A95E0",
    accent_text="#FFFFFF",
    user_bubble="#E7EEF9",
    assistant_bubble="#FFFFFF",
    danger="#D14343",
)


def get_palette(name: str) -> Palette:
    return LIGHT if str(name).lower() == "light" else MIDNIGHT


FONT_SCALE = {"Small": 0.9, "Normal": 1.0, "Large": 1.15}


def scaled(size: int, scale_name: str) -> int:
    return max(8, int(round(size * FONT_SCALE.get(scale_name, 1.0))))
