"""Async-friendly wrapper around the Google Gemini API.

Calls run in a worker thread so the Tk UI never freezes.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Callable, Optional

try:
    import google.generativeai as genai
except ImportError:  # pragma: no cover
    genai = None  # type: ignore[assignment]


@dataclass
class ChatMessage:
    role: str  # "user" or "model"
    text: str
    image_path: Optional[str] = None


@dataclass
class GeminiResult:
    ok: bool
    text: str = ""
    error: str = ""
    token_count: int = 0


@dataclass
class GeminiClient:
    api_key: str = ""
    model_name: str = "gemini-2.5-flash"
    system_prompt: str = ""
    _configured_key: str = field(default="", init=False, repr=False)

    def configure(self, api_key: str) -> None:
        if genai is None:
            return
        if api_key and api_key != self._configured_key:
            genai.configure(api_key=api_key)
            self._configured_key = api_key
            self.api_key = api_key

    def _build_history(self, history: list[ChatMessage]) -> list[dict]:
        out: list[dict] = []
        for m in history:
            parts: list = [m.text] if m.text else []
            out.append({"role": m.role, "parts": parts})
        return out

    def send_async(
        self,
        prompt: str,
        history: list[ChatMessage],
        on_done: Callable[[GeminiResult], None],
        image_path: Optional[str] = None,
    ) -> None:
        """Send a message in a background thread.

        on_done is invoked with the GeminiResult when the call completes.
        """

        def worker() -> None:
            result = self._send(prompt, history, image_path)
            on_done(result)

        threading.Thread(target=worker, daemon=True).start()

    def _send(
        self,
        prompt: str,
        history: list[ChatMessage],
        image_path: Optional[str] = None,
    ) -> GeminiResult:
        if genai is None:
            return GeminiResult(
                ok=False,
                error="google-generativeai is not installed. Run: pip install google-generativeai",
            )
        if not self.api_key:
            return GeminiResult(ok=False, error="No API key configured. Open Settings to add it.")

        try:
            self.configure(self.api_key)
            model = genai.GenerativeModel(
                model_name=self.model_name,
                system_instruction=self.system_prompt or None,
            )
            chat = model.start_chat(history=self._build_history(history))

            content: list = [prompt] if prompt else []
            if image_path:
                try:
                    from PIL import Image  # local import to keep startup fast

                    content.append(Image.open(image_path))
                except Exception as exc:  # noqa: BLE001
                    return GeminiResult(ok=False, error=f"Could not open image: {exc}")

            response = chat.send_message(content if content else " ")
            text = getattr(response, "text", "") or ""

            tokens = 0
            try:
                usage = getattr(response, "usage_metadata", None)
                if usage is not None:
                    tokens = int(getattr(usage, "total_token_count", 0))
            except Exception:  # noqa: BLE001
                tokens = 0

            return GeminiResult(ok=True, text=text, token_count=tokens)
        except Exception as exc:  # noqa: BLE001
            return GeminiResult(ok=False, error=str(exc))
