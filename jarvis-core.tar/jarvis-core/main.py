"""Entry point for JARVIS-CORE. Run with: python main.py"""
from jarvis_core.app import run


if __name__ == "__main__":
    run()
