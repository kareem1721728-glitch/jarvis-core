"""PyInstaller build script for JARVIS-CORE.

Produces a single standalone Windows EXE:

    python build.py

Output: dist/JARVIS-CORE.exe
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


APP_NAME = "JARVIS-CORE"
ENTRY = "main.py"
ICON_PATH = "assets/jarvis.ico"  # optional


def main() -> int:
    root = Path(__file__).parent.resolve()
    os.chdir(root)

    # Clean previous artifacts
    for d in ("build", "dist", "__pycache__"):
        path = root / d
        if path.exists():
            shutil.rmtree(path, ignore_errors=True)
    spec_file = root / f"{APP_NAME}.spec"
    if spec_file.exists():
        spec_file.unlink()

    cmd: list[str] = [
        sys.executable,
        "-m",
        "PyInstaller",
        ENTRY,
        "--name",
        APP_NAME,
        "--onefile",
        "--windowed",
        "--clean",
        "--noconfirm",
        # CustomTkinter ships JSON theme files & assets that PyInstaller misses.
        "--collect-all",
        "customtkinter",
        # Required runtime hidden imports for Gemini SDK.
        "--collect-submodules",
        "google.generativeai",
        "--collect-submodules",
        "google.ai.generativelanguage",
    ]

    # Bundle assets directory if present
    assets_dir = root / "assets"
    if assets_dir.exists():
        sep = ";" if os.name == "nt" else ":"
        cmd += ["--add-data", f"assets{sep}assets"]

    icon_file = root / ICON_PATH
    if icon_file.exists():
        cmd += ["--icon", str(icon_file)]

    print("Running:", " ".join(cmd))
    completed = subprocess.run(cmd)
    if completed.returncode != 0:
        print("\n[!] PyInstaller build failed.", file=sys.stderr)
        return completed.returncode

    out = root / "dist" / (f"{APP_NAME}.exe" if os.name == "nt" else APP_NAME)
    print(f"\nBuild complete: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
