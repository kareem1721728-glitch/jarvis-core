# JARVIS-CORE — The Nexa Evolution

A lightweight Windows desktop AI assistant. Inspired by Nexa's UI, powered by Google Gemini, optimized for low-end hardware (target footprint < 150 MB RAM).

## Features

- **Nexa-style UI** — sidebar navigation, Midnight + Light themes, rounded cards, toast notifications.
- **Gemini integration** — switch between Flash and Pro models from Settings.
- **Async API calls** — the UI never freezes while a response streams in.
- **System command terminal** — toggle "Terminal" mode in the title bar; AI code blocks become runnable PowerShell commands behind a Confirm dialog.
- **Custom commands** — save reusable shell or AI commands and run them in one click.
- **Vision & files** — attach images or paste text files into the chat input.
- **Auto-save** — settings, API key, and chat history persist to `config.json`.
- **Token usage indicator** — shown in the title bar.

## Run from source

```bash
pip install -r requirements.txt
python main.py
```

Open **Settings → Gemini API key**, paste your key from <https://aistudio.google.com/apikey>, then start chatting.

## Build a single-file Windows EXE

```bash
python build.py
```

The standalone executable lands in `dist/JARVIS-CORE.exe` (windowed, no console).

## Project layout

```
jarvis-core/
├── main.py                       # entry point
├── build.py                      # PyInstaller build script
├── requirements.txt
├── assets/
└── jarvis_core/
    ├── app.py                    # main shell, sidebar, theme switching
    ├── config.py                 # JSON config persistence
    ├── gemini_client.py          # async Gemini wrapper
    ├── system_runner.py          # PowerShell/sh executor
    ├── theme.py                  # Midnight + Light palettes
    └── ui/
        ├── widgets.py            # Card, Toast, IconButton, SettingRow
        ├── chat_view.py          # transcript + input
        ├── commands_view.py      # custom commands manager
        ├── settings_view.py      # all settings cards
        └── profile_view.py       # local profile summary
```

Config is stored at `%APPDATA%/JARVIS-CORE/config.json` on Windows, or `~/.jarvis-core/config.json` elsewhere.
